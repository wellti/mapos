
<!--Footer-part-->
<div class="row-fluid">
    <div id="footer" class="span12"> <a href="https://github.com/RamonSilva20/mapos" target="_blank">
        <?= date('Y'); ?> &copy; Map-OS - Ramon Silva </a></div>
  </div>
  <!--end-Footer-part-->
  <script src="<?= base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?= base_url(); ?>assets/js/matrix.js"></script>
</body>

</html>

