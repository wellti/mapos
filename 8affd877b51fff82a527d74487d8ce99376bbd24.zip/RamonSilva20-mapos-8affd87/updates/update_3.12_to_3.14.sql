ALTER TABLE `produtos` ADD `codDeBarra` VARCHAR(70) NULL AFTER `idProdutos`;
